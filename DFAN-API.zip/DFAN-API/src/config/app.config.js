module.exports = {
    SENDERS_EMAIL: "harshcomp25@gmail.com",
    SENDERS_EMAIL_PASSWORD: "#Comp@1234",
   
  };