module.exports = {
    AWS_ACCESS_KEY_ID: "AKIAXIMPBB6DPSCR3SU7",
    AWS_SECRET_ACCESS_KEY: "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",
    BUCKET_NAME: "dfan",
    REGION:'us-east-2',
  };